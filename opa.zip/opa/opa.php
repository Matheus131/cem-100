<!DOCTYPE html>
<html>

<head>
<link href="style.css"
rel="stylesheet">
<title>Receitas melhor que o tudo gostoso -PROVISORIO-</title>
</head>

<body>
<div class="nav">
  <p class="logotxt"> RASCUNHO GOSTOSO</p>
  <img class="logo" src="https://1.bp.blogspot.com/-XiX5H7dQF48/YNzHwF9saHI/AAAAAAAAF-A/Z0WA9QT4aN4_dJ5yIS3iJwh4OEm98cPPwCLcBGAsYHQ/s320/bitmap.png"/><br>
  <a class="fontside" href="#">Seu perfil</a><br><br>
  <a class="fontside" href="#">Categorias</a><br><br>
  <a class="fontside" href="#">Suas receitas</a><br><br>
  <a class="fontside" href="#">Favoritos</a><br><br>
  <a class="fontside" href="#">Configurações</a><br><br>
  <a class="fontside" href="#">Contato</a><br><br>
</div>

<h1 style="text-align:center; color:white">Rascunho Gostoso</h1>
<font color="#FFFFFF"> 
<div class="main">

<a href="" class="receita" >Chocolate quente cremoso</a><br>
<img class="imgrec" src="https://revistasaboresdosul.com.br/wp-content/uploads/2020/05/chocolate-quente-de-gramado-640x428.jpg"/><br>

    
<?php
  $data = new DateTime('7-07-2021');
  echo $data->format('d-m-Y');?>
<br>
<br/>    
    
<a href="" class="receita" >Brownie</a><br>
<img class="imgrec" src="https://th.bing.com/th/id/OIP.J6LEN7waJnGL9pWWZfUnCgEsDI?pid=ImgDet&rs=1"/><br>
    
<?php
  $data = new DateTime('25-06-2021');
  echo $data->format('d-m-Y');?>
<br>
<br/>    

<a href="" class="receita" >Pernil assado com batata</a><br>
<img class="imgrec" src="https://img.itdg.com.br/images/recipes/000/057/100/7681/7681_original.jpg"/><br>
    
<?php
  $data = new DateTime('11-06-2021');
  echo $data->format('d-m-Y');?>
<br>
<br/>    

<a href="" class="receita" >Lasanha de carne moida</a><br>
<img class="imgrec" src="https://img.cybercook.com.br/receitas/564/lasanha-de-carne-moida-2.jpeg"/><br>

<?php
  $data = new DateTime('20-05-2021');
  echo $data->format('d-m-Y');?>
<br>
<br/>    
    
<a href="" class="receita" >Caldo de mandioca</a><br>
<img class="imgrec" src="https://www.tudogostoso.com.br/images/recipes/000/185/521/253994/253994_original.jpg"/><br>

<?php
  $data = new DateTime('25-11-2020');
  echo $data->format('d-m-Y');?>
<br>
<br/>

<a href="" class="receita" >Esfiha de carne</a><br>
<img class="imgrec" src="https://www.tudogostoso.com.br/images/recipes/000/024/485/29753/29753_original.jpg?mode=crop&width=600&height=450"/><br>

   
    
<?php
  $data = new DateTime('25-04-2020');
  echo $data->format('d-m-Y');?><br><br/>    
    
<a href="" class="receita" >Macarrão com requeijão</a><br>
<img class="imgrec" src="https://portodeminas.com.br/wp-content/uploads/2019/11/capa-macarrao-com-alho.jpg"/><br>

 

<?php
  $data = new DateTime('27-03-2020');
  echo $data->format('d-m-Y');?><br><br/>
</font>
 
    </div>

</body>
</html>